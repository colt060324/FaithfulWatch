export default function Header(){ 
  return (
    <header>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <div>
          <h1>FaithfulWatch — Through Scripture's Eyes (NKJV)</h1>
          <div className="muted">FaithfulWatch gathers U.S. news and presents it through the truth of Scripture (NKJV). Our mission is to encourage discernment, balance, and faith in a divided world.</div>
        </div>
      </div>
    </header>
  )
}
