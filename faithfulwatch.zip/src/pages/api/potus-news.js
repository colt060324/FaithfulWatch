export default function handler(req,res){
  res.status(200).json([{source:'White House', headline:'POTUS official statement placeholder'}])
}
