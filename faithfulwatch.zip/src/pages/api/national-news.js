export default function handler(req, res){
  const data = {
    left: [
      { source: "NPR", headline: "Administration announces climate initiative" },
      { source: "NYTimes", headline: "New spending proposal aims to expand healthcare" }
    ],
    right: [
      { source: "Fox News", headline: "Republicans push border security measures" },
      { source: "WSJ", headline: "Debate over fiscal policy intensifies" }
    ],
    potus: [
      { source: "White House", headline: "POTUS meets bipartisan leaders on security" }
    ],
    local: [
      { source: "Orlando Sentinel", headline: "Local churches host unity prayer night" }
    ]
  };
  res.status(200).json(data);
}
