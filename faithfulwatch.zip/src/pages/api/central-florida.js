export default function handler(req,res){
  res.status(200).json([{source:'Orlando Sentinel', headline:'Local event placeholder'}])
}
