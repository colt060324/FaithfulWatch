import Header from '../components/Header'
import Footer from '../components/Footer'
import { useEffect, useState } from 'react'

export default function Home(){
  const [verse, setVerse] = useState(null)
  const [news, setNews] = useState({left:[], right:[], potus:[], local:[]})
  useEffect(()=>{
    async function load(){
      try{
        const [vRes, nRes] = await Promise.all([
          fetch('/api/daily-verse').then(r=>r.json()),
          fetch('/api/national-news').then(r=>r.json())
        ])
        setVerse(vRes)
        setNews(nRes)
      }catch(e){ console.error(e) }
    }
    load()
  },[])
  return (
    <div className="container">
      <Header />
      <main className="grid">
        <div>
          <div className="card">
            <div className="verse"><strong>Daily NKJV:</strong> {verse ? `${verse.reference} — ${verse.text}` : 'Loading...'}</div>
            <h3 className="section-title">Balanced National Coverage</h3>
            <div style={{display:'flex',gap:12}}>
              <div style={{flex:1}}>
                <h4 className="muted">Democratic-side</h4>
                <ul className="news-list">
                  {(news.left||[]).map((a,i)=>(
                    <li key={i}><strong>{a.headline}</strong><div className="muted">{a.source}</div></li>
                  ))}
                </ul>
              </div>
              <div style={{flex:1}}>
                <h4 className="muted">Republican-side</h4>
                <ul className="news-list">
                  {(news.right||[]).map((a,i)=>(
                    <li key={i}><strong>{a.headline}</strong><div className="muted">{a.source}</div></li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <div className="card" style={{marginTop:12}}>
            <h3 className="section-title">POTUS & Government</h3>
            <ul className="news-list">
              {(news.potus||[]).map((a,i)=>(<li key={i}><strong>{a.headline}</strong><div className="muted">{a.source}</div></li>))}
            </ul>
          </div>

          <div className="card" style={{marginTop:12}}>
            <h3 className="section-title">Central Florida</h3>
            <ul className="news-list">
              {(news.local||[]).map((a,i)=>(<li key={i}><strong>{a.headline}</strong><div className="muted">{a.source}</div></li>))}
            </ul>
          </div>
        </div>

        <aside>
          <div className="card">
            <h3 className="section-title">Devotional</h3>
            <p className="muted">Short reflection:</p>
            <p>{verse ? verse.reflection : 'Loading...'}</p>
          </div>

          <div className="card" style={{marginTop:12}}>
            <h3 className="section-title">Subscribe</h3>
            <p className="muted">Enter your email at admin to enable daily email digests (SendGrid setup required).</p>
          </div>
        </aside>
      </main>

      <Footer />
    </div>
  )
}
