# FaithfulWatch — Through Scripture's Eyes (NKJV)

This is a minimal Next.js starter for FaithfulWatch, a Christian news aggregator that:
- Shows balanced national coverage (Democratic + Republican perspectives)
- Displays POTUS updates
- Displays Central Florida local news
- Shows a daily NKJV verse with a short reflection
- Includes API endpoints (mock data) you can replace with real feeds

## Quick start (deploy to Vercel)
1. Sign in to GitHub and create a new repository named `faithfulwatch`.
2. Upload the contents of this project.
3. Sign in to Vercel and import the GitHub repo.
4. Deploy — Vercel will detect Next.js and publish the site.
5. Your API endpoints will be available under `/api/*` (e.g., `/api/daily-verse`, `/api/national-news`).

## Notes
- The API endpoints currently return mock data for immediate testing.
- When ready, replace the API logic to fetch real news via NewsAPI, Bing News, or RSS feeds.
- To enable email digests, add SendGrid and update `src/pages/api/send-notification.js`.

Mission statement:
> FaithfulWatch gathers U.S. news and presents it through the truth of Scripture (NKJV). Our mission is to encourage discernment, balance, and faith in a divided world.
