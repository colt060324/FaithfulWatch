export default function Footer(){
  return (
    <footer>
      © {new Date().getFullYear()} FaithfulWatch — Viewed through Scripture (NKJV) — a reflection, not a prophecy.
    </footer>
  )
}
