export default function handler(req, res){
  const verses = [
    { reference: "Psalm 33:12 NKJV", text: "Blessed is the nation whose God is the Lord...", reflection: "Blessed are those who seek the Lord." },
    { reference: "Isaiah 26:3 NKJV", text: "You will keep him in perfect peace...", reflection: "Fix your mind on God and find peace." },
    { reference: "Proverbs 21:1 NKJV", text: "The king's heart is in the hand of the Lord...", reflection: "Leaders are under God's sovereign control." }
  ];
  const idx = new Date().getDate() % verses.length;
  res.status(200).json(verses[idx]);
}
